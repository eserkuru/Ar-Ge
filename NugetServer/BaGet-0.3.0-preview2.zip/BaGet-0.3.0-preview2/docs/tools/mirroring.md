# Mirroring nuget.org

!!! warning
    This page is a work in progress!

## Importing package downloads from nuget.org

You can import package downloads from nuget.org:

1. Navigate to `.\BaGet\src\BaGet`
2. Run:

```
dotnet run -- import-downloads
```

## Indexing nuget.org

* TODO Check-in code
* Explain scaling
* Rebuild indexes at end
* Importing downloads from nuget.org