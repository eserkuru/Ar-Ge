Summary of the changes (in less than 80 chars)

 * Detail 1
 * Detail 2

Addresses https://github.com/loic-sharma/BaGet/issues/123
