//---------------------------------------------------------------------------
#ifndef grH
#define grH

//---------------------------------------------------------------------------
// gradient fill
void __fastcall FillVolume(TCanvas * c, TRect rect, TColor color, double brightness_range_koeff=0.5);
//---------------------------------------------------------------------------
#endif
