# Sponsors

We thank those who [support](https://www.patreon.com/identityserver) IdentityServer!

## Corporate

### Platinum
[Udelt](https://udelt.no/)  
[Microsoft .NET](https://github.com/dotnet-at-microsoft)

### Gold

[Thinktecture AG](https://www.thinktecture.com)   ([@Thinktecture](https://twitter.com/thinktecture))  
[Ritter Insurance Marketing](https://www.ritterim.com) ([@RitterIM](https://twitter.com/ritterim))   
[Intuit](https://www.intuit.com) ([@IntuitDev](https://twitter.com/IntuitDev))  
[ExtranetUserManager](https://www.extranetusermanager.com) ([@eumgr](https://twitter.com/eumgr))  

### Silver

Jacobus Roos  
Soluto ([@SolutoEng](https://twitter.com/SolutoEng))  
Steinar	Noem  
Effectory ([@effectory](https://twitter.com/effectory))  
Real Page ([@RealPage](https://twitter.com/RealPage))  
FireGiant ([@firegiantco](https://twitter.com/firegiantco))  
Justify ([@justify_legal](https://twitter.com/justify_legal))

## Individuals

Khalid Abuhakmeh ([@buhakmeh](https://twitter.com/buhakmeh))  
Rasika Weliwita ([@rasikaweliwita](https://twitter.com/rasikaweliwita))  
Arun David Shelly  
Reece Williams ([@AnEmptyReece](https://twitter.com/AnEmptyReece))  
Alexander Zeitler ([@alexzeitler_](https://twitter.com/alexzeitler_))  
Tobias Höft ([@tobiashoeft](https://twitter.com/tobiashoeft))  
Gusztav Varga ([@gusztavvargadr](https://twitter.com/gusztavvargadr))  
William Grow  
James Roberts  
Chris Simmons ([@netchrisdotcom](https://twitter.com/netchrisdotcom))  
Shawn Wildermuth  
Thomas C  
Ben	Cull  
Johan Boström ([@zarx](https://twitter.com/zarx))  
Chris White  
Albert ([@DerAlbert](https://twitter.com/DerAlbert))  
Hugo Biarge ([@hbiarge](https://twitter.com/hbiarge))  
Ibrahim Šuta ([@ibrahimsuta](https://twitter.com/ibrahimsuta))  
Dave Noderer  ([@davenoderer](https://twitter.com/davenoderer))  
VIJAYA PAL NALLALA  
Martijn Boland  
Giuseppe Turitto  
Mauricio Schneider  
Norman L Covington  
Henning Støverud  ([@henningst](https://twitter.com/henningst))  
Ryan Mendoza  ([@elryry](https://twitter.com/elryry))  
Colin Blair  
Erik Gulbrandsen  
Olga Klimova  
Alexandru Puiu  
Michael Calasanz  
Fredrik Karlsson ([@fredrik_zenit](https://twitter.com/fredrik_zenit))  
Steve Graddy  
Jeremy Sinclair ([@sinclairinator](https://twitter.com/sinclairinator))  
Veikko Eeva  
Bruno Brito  
James Hough  
